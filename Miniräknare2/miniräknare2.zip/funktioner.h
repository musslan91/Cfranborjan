void menu();
void addition();
void subtraktion();
void multiplikation();
void division();
